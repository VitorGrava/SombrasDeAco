using UnityEngine;

public class MovimentoCamera : MonoBehaviour
{
    [Header("Referências")]
    public Transform player;
    [Tooltip("Opcional: se vazio, a câmera não é limitada.")]
    public Transform limiteEsquerda;
    public Transform limiteDireita;

    [Header("Suavização")]
    [SerializeField] private float suavizacaoZ = 0.15f;
    [SerializeField] private float suavizacaoY = 0.2f;

    [Header("Look-Ahead (antecipa direção)")]
    [SerializeField] private float distanciaLookAhead = 2.5f;
    [SerializeField] private float suavizacaoLookAhead = 0.3f;

    [Header("Dead Zone")]
    [SerializeField] private bool usarDeadZone = true;
    [SerializeField] private float deadZoneZ = 0.5f;

    [Header("Seguir Y")]
    [SerializeField] private bool seguirY = false;
    [SerializeField] private float offsetY = 0f;

    [Header("Offset base")]
    [SerializeField] private float offsetZ = 0f;

    private float velocidadeRefZ;
    private float velocidadeRefY;
    private float lookAheadAtual;
    private float velocidadeLookAhead;
    private float ultimaDirecao = 1f;
    private Rigidbody playerRb;

    private void Start()
    {
        if (player == null)
        {
            GameObject obj = GameObject.FindGameObjectWithTag("Player");
            if (obj != null) player = obj.transform;
        }
        if (player == null) { enabled = false; return; }

        playerRb = player.GetComponent<Rigidbody>();

        // Começa direto na posição do player (sem slide inicial)
        transform.position = new Vector3(
            transform.position.x,
            seguirY ? player.position.y + offsetY : transform.position.y,
            player.position.z + offsetZ
        );
    }

    private void LateUpdate()
    {
        float velocidadePlayer = playerRb != null ? playerRb.linearVelocity.z : 0f;
        AtualizarLookAhead(velocidadePlayer);

        float alvoZ = player.position.z + offsetZ + lookAheadAtual;

        // Dead zone: só move se o player saiu da zona central
        if (usarDeadZone && Mathf.Abs(alvoZ - transform.position.z) < deadZoneZ)
            alvoZ = transform.position.z;

        // Limites do mapa (no eixo Z)
        if (limiteEsquerda != null && limiteDireita != null)
        {
            float min = Mathf.Min(limiteEsquerda.position.z, limiteDireita.position.z);
            float max = Mathf.Max(limiteEsquerda.position.z, limiteDireita.position.z);
            alvoZ = Mathf.Clamp(alvoZ, min, max);
        }

        float alvoY = seguirY ? player.position.y + offsetY : transform.position.y;

        float novoZ = Mathf.SmoothDamp(transform.position.z, alvoZ, ref velocidadeRefZ, suavizacaoZ);
        float novoY = Mathf.SmoothDamp(transform.position.y, alvoY, ref velocidadeRefY, suavizacaoY);

        // X não muda: é a distância da câmera até o cenário
        transform.position = new Vector3(transform.position.x, novoY, novoZ);
    }

    private void AtualizarLookAhead(float velocidade)
    {
        if (velocidade > 0.1f) ultimaDirecao = 1f;
        else if (velocidade < -0.1f) ultimaDirecao = -1f;

        float alvo = Mathf.Abs(velocidade) > 0.1f ? ultimaDirecao * distanciaLookAhead : 0f;

        lookAheadAtual = Mathf.SmoothDamp(lookAheadAtual, alvo, ref velocidadeLookAhead, suavizacaoLookAhead);
    }
}