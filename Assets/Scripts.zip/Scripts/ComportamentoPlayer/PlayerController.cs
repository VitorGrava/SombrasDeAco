using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Velocidades
    public float velocidadeAndando;
    public float velocidadeAgachando;
    public float velocidadeCorrendo;

    // Rotação
    public float velocidadeRotacao;
    private float RotYLoc = 0f;

    // Pulo
    public float forcaPulo;
    public bool noChao;

    // ---- MELHORIAS DO PULO ----
    public float coyoteTime = 0.15f;
    public float jumpBufferTime = 0.15f;

    // Multiplicadores de queda (sensação de peso)
    public float gravityMultiplier = 2.5f;     // cai mais rápido
    public float lowJumpMultiplier = 2.0f;     // pulo curto ao soltar cedo

    private float coyoteCounter;
    private float jumpBufferCounter;
    // ----------------------------

    private float moveInput;

    public enum EstadoMovimento { Andando, Agachando, Correndo }
    private EstadoMovimento estadoAtual;

    private Animator animator;
    private Rigidbody rb;
    private Vector3 posicaoAtual;

    [HideInInspector] public ControleStamina controleStamina;

    void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();
        controleStamina = GetComponent<ControleStamina>();
    }

    public void SetVelocidadeCorrrendo(float velocidade)
    {
        velocidadeCorrendo = velocidade;
    }

    // Update: apenas leitura de input do pulo (GetButtonDown só é confiável aqui)
    void Update()
    {
        if (Input.GetButtonDown("Jump"))
            jumpBufferCounter = jumpBufferTime;
    }

    void FixedUpdate()
    {
        if (GerenciadorEstadoJogador.Instancia != null && GerenciadorEstadoJogador.Instancia.EstaEscondido())
            return;

        MovimentacaoPlayer();
        AtualizarEstadoMovimento();
        Pulo();
        AplicarGravidade();
    }

    void MovimentacaoPlayer()
    {
        moveInput = Input.GetAxis("Horizontal");

        // Movimento no eixo Z (lado da tela)
        posicaoAtual = new Vector3(0f, 0f, moveInput);

        switch (estadoAtual)
        {
            case EstadoMovimento.Andando:
                rb.MovePosition(rb.position + posicaoAtual * velocidadeAndando * Time.fixedDeltaTime);
                if (animator != null) animator.SetBool("IsCrouching", false);
                if (controleStamina != null) controleStamina.estaCorrendo = false;
                break;

            case EstadoMovimento.Agachando:
                rb.MovePosition(rb.position + posicaoAtual * velocidadeAgachando * Time.fixedDeltaTime);
                if (animator != null) animator.SetBool("IsCrouching", true);
                if (controleStamina != null) controleStamina.estaCorrendo = false;
                break;

            case EstadoMovimento.Correndo:
                rb.MovePosition(rb.position + posicaoAtual * velocidadeCorrendo * Time.fixedDeltaTime);
                if (animator != null) animator.SetBool("IsCrouching", false);

                // Só consome stamina se estiver se movendo
                if (moveInput != 0)
                {
                    if (controleStamina != null)
                    {
                        controleStamina.estaCorrendo = true;
                        controleStamina.Correndo();
                    }
                }
                else
                {
                    if (controleStamina != null) controleStamina.estaCorrendo = false;
                }
                break;
        }

        Rotacao(moveInput);
        if (animator != null) animator.SetBool("IsMoving", moveInput != 0);
    }

    void AtualizarEstadoMovimento()
    {
        if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
        {
            estadoAtual = (controleStamina != null && controleStamina.stamina > 0)
                ? EstadoMovimento.Correndo
                : EstadoMovimento.Andando;
            return;
        }

        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            estadoAtual = EstadoMovimento.Agachando;
            return;
        }

        estadoAtual = EstadoMovimento.Andando;
    }

    // SISTEMA DE PULO (jumpBufferCounter vem do Update)
    void Pulo()
    {
        jumpBufferCounter -= Time.fixedDeltaTime;

        // Coyote time
        if (noChao)
            coyoteCounter = coyoteTime;
        else
            coyoteCounter -= Time.fixedDeltaTime;

        // Executa o pulo
        if (jumpBufferCounter > 0 && coyoteCounter > 0)
        {
            // Zera só a velocidade vertical, preservando o movimento
            rb.linearVelocity = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z);
            rb.AddForce(new Vector3(0f, forcaPulo, 0f), ForceMode.Impulse);

            jumpBufferCounter = 0;
            coyoteCounter = 0;
        }
    }

    // GRAVIDADE MELHORADA: cai pesado; pulo curto ao soltar cedo
    void AplicarGravidade()
    {
        if (rb.linearVelocity.y < 0)
        {
            rb.AddForce(Vector3.up * Physics.gravity.y * (gravityMultiplier - 1f) * rb.mass * Time.fixedDeltaTime, ForceMode.Force);
        }
        else if (rb.linearVelocity.y > 0 && !Input.GetButton("Jump"))
        {
            rb.AddForce(Vector3.up * Physics.gravity.y * (lowJumpMultiplier - 1f) * rb.mass * Time.fixedDeltaTime, ForceMode.Force);
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Pulavel"))
            noChao = true;
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Pulavel"))
            noChao = false;
    }

    // Rotação: 0° = +Z (direita da tela), 180° = -Z (esquerda da tela)
    private void Rotacao(float input)
    {
        if (input > 0) RotYLoc = 0f;
        else if (input < 0) RotYLoc = 180f;

        float yAtual = transform.eulerAngles.y;
        float yNovo = Mathf.LerpAngle(yAtual, RotYLoc, velocidadeRotacao * Time.deltaTime);
        transform.eulerAngles = new Vector3(0f, yNovo, 0f);
    }
}